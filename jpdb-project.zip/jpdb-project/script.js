const BASE_URL = "http://api.login2explore.com:5577";
const PUT_URL = "/api/iml";
const GET_URL = "/api/irl";

// ⭐ Apna JSONPowerDB Token yaha paste karo
const TOKEN = "YOUR-CONNECTION-TOKEN"; 

const DB_NAME = "COLLEGE_DB";
const REL_NAME = "STUDENT_TABLE";

// -------------------- SAVE DATA (PUT) ------------------------
function saveData() {
    let roll = document.getElementById("roll").value;
    let name = document.getElementById("name").value;
    let cls = document.getElementById("cls").value;

    let jsonStr = { roll: roll, name: name, class: cls };

    let putReq = {
        token: TOKEN,
        dbName: DB_NAME,
        rel: REL_NAME,
        jsonStr: JSON.stringify(jsonStr)
    };

    sendRequest(PUT_URL, putReq);
}

// -------------------- GET DATA ------------------------
function getData() {
    let roll = document.getElementById("roll").value;

    let getReq = {
        token: TOKEN,
        dbName: DB_NAME,
        rel: REL_NAME,
        cmd: "GET_BY_KEY",
        jsonStr: JSON.stringify({ roll: roll })
    };

    sendRequest(GET_URL, getReq, (response) => {
        let data = JSON.parse(response.data).record;
        document.getElementById("name").value = data.name;
        document.getElementById("cls").value = data.class;
    });
}

// -------------------- UPDATE DATA ------------------------
function updateData() {
    let roll = document.getElementById("roll").value;
    let name = document.getElementById("name").value;
    let cls = document.getElementById("cls").value;

    let updateReq = {
        token: TOKEN,
        dbName: DB_NAME,
        rel: REL_NAME,
        cmd: "UPDATE",
        jsonStr: JSON.stringify({
            roll: roll,
            name: name,
            class: cls
        })
    };

    sendRequest(PUT_URL, updateReq);
}

// -------------------- DELETE DATA ------------------------
function deleteData() {
    let roll = document.getElementById("roll").value;

    let delReq = {
        token: TOKEN,
        dbName: DB_NAME,
        rel: REL_NAME,
        cmd: "REMOVE",
        jsonStr: JSON.stringify({ roll: roll })
    };

    sendRequest(PUT_URL, delReq);
}

// -------------------- COMMON REQUEST FUNCTION ------------------------
function sendRequest(url, data, callback = null) {
    let xhr = new XMLHttpRequest();
    xhr.open("POST", BASE_URL + url, true);
    xhr.setRequestHeader("Content-Type", "application/json");

    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4) {
            let resp = JSON.parse(xhr.responseText);
            alert("Response: " + xhr.responseText);

            if (callback) callback(resp);
        }
    };

    xhr.send(JSON.stringify(data));
}
